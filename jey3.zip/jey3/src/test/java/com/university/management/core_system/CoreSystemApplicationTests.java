package com.university.management.core_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
